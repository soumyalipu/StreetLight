
<?php
class EntityArea
{
	public $ID;
	public $area_name;
	public $Longitude;
	public $Latitude;
}
?>