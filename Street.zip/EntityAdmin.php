
<?php
class EntityAdmin
{
	public $ID;
	public $ADMINID;
	public $ADMINPASS;
	public $ADMINEMAIL;
	public $ADMINMOBILE;
	public $ADMINSTATUS;
}
?>