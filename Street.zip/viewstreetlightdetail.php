<?php
ob_start();
    include("connection.php");
  include("function.php");
  if(!isset($_SESSION['user']))
{
    header("Location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php headContent("FILENAME");?>
</head>
<body class="animsition">
<div class="page-wrapper">

  <!-- Navbar -->
  
  <!-- /.navbar -->

  <!-- Start: Main Sidebar Container -->
  <?php $utype=$_SESSION['usertype'];mobile($utype); sideBar($utype); ?>
  <!-- End: Main Sidebar Container -->

  <!-- Content Wrapper. Contains page content -->
  <div class="page-container">
  <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap" style="float: right;">
                            
                            <div class="header-button">
                                
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#"><?php if ($_SESSION['usertype']=="Admin") {
                                            	echo"Admin";
                                            }else{echo"Super Admin";}?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                                                    </a>
                                                </div>
                                                <div class="content">

                                                    <h5 class="name">
                                                        <a href="#"><?php if ($_SESSION['usertype']=="Admin") {
                                            	echo"Admin";
                                            }else{echo"Superadmin";}?></a>
                                                    </h5>
                                                    <span class="email"><?php if ($_SESSION['usertype']=="Admin") {
                                            	echo $_SESSION['user'];
                                            }else{echo $_SESSION['user'];}?></span>
                                                </div>
                                            </div>
                                            
                                            <div class="account-dropdown__footer">
                                                <a href="logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if ($_SESSION['usertype']=="Sadmin") {
                                    ?>
                                    <div class="ml-5">
                                    <button class="btn btn-lg btn-info">
                                        <a style="color:white;" href="chartview.php?Sl_id=<?php echo $_GET['SL_ID']?>&&Phase=<?php echo $_GET['Phase'] ?>">
                                        <i class="fa fa-bar-chart-o"></i>
                                        </a>
                                    </button>
                                </div>
                                    <?php
                                } ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </header>
  <?php
  if ($_GET['Phase']==1) {
        require_once("EntitySinglephase.php");
        require_once("ModelSinglephase.php");
        require_once("connection.php");
        global $dbc;
        $singlephase = new EntitySinglephase();
        $singlephaseModel = new ModelSinglephase($dbc);

        $ArrayList = $singlephaseModel -> GetSinglephaseBySl_id($_GET['SL_ID']);
  }
  elseif ($_GET['Phase']==3) {
        require_once("EntityMultiphase.php");
        require_once("ModelMultiphase.php");
        require_once("connection.php");
        global $dbc;
        $multiphase = new EntityMultiphase();
        $multiphaseModel = new ModelMultiphase($dbc);

        $ArrayList = $multiphaseModel -> GetMultiphaseBySl_id($_GET['SL_ID']);
  }
  foreach($ArrayList as $row){
    
  }
?>
    <!-- Main content -->
    <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="title-1"><?php echo "CCMS Id - ".$_GET['SL_ID']; ?></h2>

                                    <div style=" float: left;">
                                         
                                            
                                            
                                      <label class="switch switch-text switch-primary switch-pill" >
                                      <input type="checkbox" class="switch-input " id="SMODE" <?php if ($row->SMODE==1){
                                                    echo"checked";
                                                  } ?> onclick="getValue('SMODE');">
                                      <span data-on="Manual" data-off="Auto" class="switch-label"></span>
                                      <span class="switch-handle"></span>
                                    </label>
                                    <label class="switch switch-text switch-success switch-pill">
                                      <input type="checkbox" class="switch-input" id="MMODE" <?php if ($row->MMODE==1){
                                                    echo"checked";
                                                  } ?> onclick="getmValue('MMODE');" <?php if ($row->SMODE==0){
                                                    echo"Disabled";
                                                  } ?>>
                                      <span data-on="On" data-off="Off" class="switch-label"></span>
                                      <span class="switch-handle"></span>
                                    </label>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="row m-t-25">
                           <div class="col-lg-12">
                                <div class="au-card chart-percent-card">
                                    <div class="au-card-inner">
                                        <div class="row">
                                                  <div class="col-lg-4 text-center">
                                                      <label for="switch" class="form-label">
                                                        <h3 class="title-2">CCMS Status</h3>
                                                      </label>
                                                         <br>
                                                    <img id="d_status" class="" src=" <?php if ($row->Device_Status==1){
                                                            echo"http://ironmanpro.in/images/icon/pon.png";
                                                    }
                                                             else{echo"http://ironmanpro.in/images/icon/poff.png";}?>">
                                                  </div>
                                                  <div class="col-lg-4 text-center">
                                                      <label for="switch" class="form-label">
                                                        <h3 class="title-2">Internet Connected</h3>
                                                      </label>
                                                      <br>
                                                      <img class="" src=" <?php if ($row->Internetconnected==1){echo"http://ironmanpro.in/images/icon/wifigreen.png";}
                                                             else{echo"http://ironmanpro.in/images/icon/wifired.png";}?>">
                                                  </div>
                                                  <div class="col-lg-4 text-center">
                                                      <div class="">
                                                          <label for="switch" class="form-label ">
                                                            <h3 class="title-2">Alarm</h3>
                                                          </label><br>
                                                          <img  src=" <?php if ($row->FAULT==0){echo"http://ironmanpro.in/images/icon/alarmgreen.png";}
                                                                 else{echo"http://ironmanpro.in/images/icon/alarmred.png";}?>">
                                                     </div>
                                                  </div>
                                                  

                                            </div>
                                            
                                    </div>
                                </div>
                            </div> 
                        </div>
                        <div class="row m-t-25" style="display:flex;">
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g1" style="margin-left: 30%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart1"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g2" style="margin-left: 30%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-shopping-cart"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart2"></canvas>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g3" style="margin-left: 30%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-calendar-note"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart3"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>  
                        <div id="mpr" style="display:none;" class="row m-t-25">
                            <div class="col-sm-6 col-lg-4">
                              <div class="overview-item ">
                                  <div class="overview__inner" id="g4" style="margin-left: 25%;">
                                      <div class="overview-box clearfix">
                                          <div class="icon">
                                              <i class="zmdi zmdi-account-o"></i>
                                          </div>
                                          <div class="text">
                                              
                                          </div>
                                      </div>
                                      <div class="overview-chart">
                                          <canvas id="widgetChart1"></canvas>
                                      </div>
                                  </div>
                              </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g5" style="margin-left: 25%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-shopping-cart"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart2"></canvas>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g6" style="margin-left: 25%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-calendar-note"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart3"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g7" style="margin-left: 25%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart1"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g8" style="margin-left: 25%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart1"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g9" style="margin-left: 25%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart1"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g13" style="margin-left: 30%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart1"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g14" style="margin-left: 30%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-shopping-cart"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart2"></canvas>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g15" style="margin-left: 30%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-calendar-note"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart3"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g10" style="margin-left: 30%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart1"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g11" style="margin-left: 30%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-shopping-cart"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart2"></canvas>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-4" id="ex">
                                <div class="overview-item ">
                                    <div class="overview__inner" id="g12" style="margin-left: 30%;">
                                        <div class="overview-box clearfix">
                                            <div class="icon">
                                                <i class="zmdi zmdi-calendar-note"></i>
                                            </div>
                                            <div class="text">
                                                
                                            </div>
                                        </div>
                                        <div class="overview-chart">
                                            <canvas id="widgetChart3"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>

                            <div class="col-lg-12" style="overflow-x: scroll;">
                              <!--Map script-->
                              <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                              <?php 
                              if ($_GET['Phase']==1) {
                                ?>
                                <script type="text/javascript">
                                  google.charts.load('current', {'packages':['gauge']});
                                  google.charts.setOnLoadCallback(drawChart);

                                  function drawChart() {

                                    var data1 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['Volt', <?php echo $row->VOLT;?>],
                                    ]);
                                    var data2 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['Current', <?php echo $row->CURRENT;?>],
                                    ]);
                                    var data3 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['Power', <?php echo $row->POWER;?>],
                                    ]);
                                    var data10 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['PF', <?php echo $row->PF;?>],
                                    ]);
                                    var data11 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['FREQUENCY', <?php echo $row->FREQUENCY;?>],
                                    ]);
                                    var data12 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['ENERGY', <?php echo $row->ENERGY;?>],
                                    ]);
                                    var options1 = {
                                        max:300,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var options2 = {
                                        max:100,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var options3 = {
                                        max:1000,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var chart1 = new google.visualization.Gauge(document.getElementById('g1'));
                                    var chart2 = new google.visualization.Gauge(document.getElementById('g2'));
                                    var chart3 = new google.visualization.Gauge(document.getElementById('g3'));
                                    var chart10 = new google.visualization.Gauge(document.getElementById('g10'));
                                    var chart11 = new google.visualization.Gauge(document.getElementById('g11'));
                                    var chart12 = new google.visualization.Gauge(document.getElementById('g12'));
                                    chart1.draw(data1, options1);
                                    chart2.draw(data2, options2);
                                    chart3.draw(data3, options3);
                                    chart10.draw(data10, options2);
                                    chart11.draw(data11, options2);
                                    chart12.draw(data12, options3);
                                  }
                                </script>
                                <?php  
                              }
                              elseif ($_GET['Phase']==3) {
                                ?>
                                <script type="text/javascript">
                                  google.charts.load('current', {'packages':['gauge']});
                                  google.charts.setOnLoadCallback(drawChart);
                                  function drawChart() {
                                    var data1 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['VoltR', <?php echo $row->VOLTR; ?>],
                                    ]);
                                    var data2 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['VoltB', <?php echo $row->VOLTB;?>],
                                    ]);
                                    var data3 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['VoltY', <?php echo $row->VOLTY;?>],
                                    ]);
                                    var data4 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['CurrentR', <?php echo $row->CURRENTR;?>],
                                    ]);

                                    var data5 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['CurrentB', <?php echo $row->CURRENTB;?>],
                                    ]);
                                    var data6 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['CurrentY', <?php echo $row->CURRENTY;?>],
                                    ]);
                                    var data7 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['PowerR', <?php echo $row->POWERR;?>],
                                    ]);
                                    var data8 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['PowerB', <?php echo $row->POWERB;?>],
                                    ]);
                                    var data9 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['PowerY', <?php echo $row->POWERY;?>],
                                    ]);
                                    var data10 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['PF R', <?php echo $row->PFR;?>],
                                    ]);
                                    var data11 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['PF B', <?php echo $row->PFB;?>],
                                    ]);
                                    var data12 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['PF Y', <?php echo $row->PFY;?>],
                                    ]);
                                    var data13 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['FREQUENCY', <?php echo $row->FREQUENCY;?>],
                                    ]);
                                    var data14 = google.visualization.arrayToDataTable([
                                      ['Label', 'Value'],
                                      ['ENERGY', <?php echo $row->ENERGY;?>],
                                    ]);
                                    var optionsvr = {
                                     max:300,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var optionsvb = {
                                     max:300,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var optionsvy = {
                                     max:300,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var optionscr = {
                                     max:100,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var optionscb = {
                                     max:100,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var optionscy = {
                                     max:100,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var optionspr = {
                                     max:1000,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var optionspb = {
                                     max:1000,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    var optionspy = {
                                     max:1000,
                                      redFrom: 90, redTo: 100,
                                      yellowFrom:75, yellowTo: 90,
                                      minorTicks: 5
                                    };
                                    document.getElementById('ex').style.display="none";
                                    document.getElementById('mpr').style.display="flex";
                                    var chart1 = new google.visualization.Gauge(document.getElementById('g1'));
                                    var chart2 = new google.visualization.Gauge(document.getElementById('g2'));
                                    var chart3 = new google.visualization.Gauge(document.getElementById('g3'));
                                    var chart4 = new google.visualization.Gauge(document.getElementById('g4'));
                                    var chart5 = new google.visualization.Gauge(document.getElementById('g5'));
                                    var chart6 = new google.visualization.Gauge(document.getElementById('g6'));
                                    var chart7 = new google.visualization.Gauge(document.getElementById('g7'));
                                    var chart8 = new google.visualization.Gauge(document.getElementById('g8'));
                                    var chart9 = new google.visualization.Gauge(document.getElementById('g9'));
                                    var chart10 = new google.visualization.Gauge(document.getElementById('g13'));
                                    var chart11 = new google.visualization.Gauge(document.getElementById('g14'));
                                    var chart12 = new google.visualization.Gauge(document.getElementById('g15'));
                                    var chart13 = new google.visualization.Gauge(document.getElementById('g10'));
                                    var chart14 = new google.visualization.Gauge(document.getElementById('g11'));
                                    chart1.draw(data1, optionsvr);
                                    chart2.draw(data2, optionsvb);
                                    chart3.draw(data3, optionsvy);
                                    chart4.draw(data4, optionscr);
                                    chart5.draw(data5, optionscb);
                                    chart6.draw(data6, optionscy);
                                    chart7.draw(data7, optionspr);
                                    chart8.draw(data8, optionspb);
                                    chart9.draw(data9, optionspy);
                                    chart10.draw(data10, optionscr);
                                    chart11.draw(data11, optionscr);
                                    chart12.draw(data12, optionscr);
                                    chart13.draw(data13, optionscr);
                                    chart14.draw(data14, optionscr);
                                  }
                                </script>
                                <?php
                              }
                              ?>
                               
                              
                            </div>
                        </div>

                        <div class="row">
                          <?php 

                            if ($_GET['Phase']==1) {
                              ?>
                              <div class="col-lg-12">
                                
                                <div class="au-card recent-report">
                                    <div class="text-dark h3 mb-3"><b>CCMS Settings</b></div>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="au-card-inner">
                                               <h3 class="title-2">Set Voltage</h3>
                                               <div class="p-2">
                                                  <label for="customRange1" class="form-label">High</label>
                                                  <input type="range" class="form-range" id="customRange1" value="<?php echo $row->HIGH_VOLT;?>" onchange="updateTextInput(this.value,'HIGH_VOLT',<?PHP echo $row->SL_ID; ?>,'textInput1');" max="300">
                                                  <input type="text" id="textInput1" value="<?php echo $row->HIGH_VOLT;?>">
                                                  <br>
                                                  <label for="customRange2" class="form-label">Low</label>
                                                  <input type="range" class="form-range" id="customRange2" value="<?php echo $row->LOW_VOLT;?>" onchange="updateTextInput(this.value,'LOW_VOLT',<?PHP echo $row->SL_ID; ?>,'textInput2');" max="300">
                                                  <input type="text" id="textInput2" value="<?php echo $row->LOW_VOLT;?>">
                                              </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="au-card-inner">
                                               <h3 class="title-2">Set Current</h3>
                                               <div class="p-2">
                                              <label for="customRange1" class="form-label">High</label>
                                              <input type="range" class="form-range" id="customRange1" value="<?php echo $row->HC;?>" onchange="updateTextInput(this.value,'HC',<?PHP echo $row->SL_ID; ?>,'textInput3');">
                                              <input type="text" id="textInput3" value="<?php echo $row->HC;?>">
                                              <br>
                                              <label for="customRange2" class="form-label">Low</label>
                                              <input type="range" class="form-range" id="customRange2" value="<?php echo $row->LC;?>" onchange="updateTextInput(this.value,'LC',<?PHP echo $row->SL_ID; ?>,'textInput4');">
                                              <input type="text" id="textInput4" value="<?php echo $row->LC;?>">
                                              </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <?php
                            }
                            elseif ($_GET['Phase']==3) {
                              ?>
                              <div class="col-lg-12">
                                <div class="au-card recent-report">
                                    <div class="text-dark h3 mb-3"><b>CCMS Settings</b></div>
                                    <div class="au-card-inner">
                                        <div class="row">
                                        <div class="col-lg-4">
                                          <h3 class="title-2">Set VoltageR</h3>
                                          <hr>
                                          <label for="customRange1" class="form-label">High</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'HVR',<?PHP echo $row->SL_ID; ?>,'textInput1');"  value="<?php echo $row->HIGH_VOLTR;?>" max="300">
                                          <input type="text" id="textInput1" value="<?php echo $row->HIGH_VOLTR;?>">
                                          <br>
                                          <label for="customRange1" class="form-label">Low</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'LVR',<?PHP echo $row->SL_ID; ?>,'textInput2');"  value="<?php echo $row->LOW_VOLTR;?>" max="300">
                                          <input type="text" id="textInput2" value="<?php echo $row->LOW_VOLTR;?>">
                                        </div>
                                        <div class="col-lg-4">
                                          <h3 class="title-2">Set VoltageB</h3>
                                          <hr>
                                          <label for="customRange1" class="form-label">High</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'HVB',<?PHP echo $row->SL_ID; ?>,'textInput3');" value="<?php echo $row->HIGH_VOLTB;?>" max="300">
                                          <input type="text" id="textInput3" value="<?php echo $row->HIGH_VOLTB;?>">
                                          <br>
                                          <label for="customRange1" class="form-label">Low</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'LVB',<?PHP echo $row->SL_ID; ?>,'textInput4');" value="<?php echo $row->LOW_VOLTB;?>"max="300">
                                          <input type="text" id="textInput4" value="<?php echo $row->LOW_VOLTB;?>">
                                        </div>
                                        <div class="col-lg-4">
                                          <h3 class="title-2">Set VoltageY</h3>
                                          <hr>
                                          <label for="customRange1" class="form-label">High</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'HBY',<?PHP echo $row->SL_ID; ?>,'textInput5');" value="<?php echo $row->HIGH_VOLTY;?>" max="300">
                                          <input type="text" id="textInput5" value="<?php echo $row->HIGH_VOLTY;?>">
                                          <br>
                                          <label for="customRange1" class="form-label">Low</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'LVY',<?PHP echo $row->SL_ID; ?>,'textInput6');" value="<?php echo $row->LOW_VOLTY;?>" max="300">
                                          <input type="text" id="textInput6" value="<?php echo $row->LOW_VOLTY;?>">
                                        </div>

                                        <!-- current-->
                                        <div class="col-lg-4 mt-5">
                                          <h3 class="title-2">Set CurrentR</h3>
                                          <hr>
                                          <label for="customRange1" class="form-label">High Current</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'HCR',<?PHP echo $row->SL_ID; ?>,'textInput7');"  value="<?php echo $row->HCR;?>">
                                          <input type="text" id="textInput7" value="<?php echo $row->HCR;?>">
                                          <br>
                                          <label for="customRange1" class="form-label">Low Current</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'LCR',<?PHP echo $row->SL_ID; ?>,'textInput8');"  value="<?php echo $row->LCR;?>">
                                          <input type="text" id="textInput8" value="<?php echo $row->LCR;?>">
                                        </div>
                                        <div class="col-lg-4 mt-5">
                                          <h3 class="title-2">Set CurrentB</h3>
                                          <hr>
                                          <label for="customRange1" class="form-label">High Current</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'HCB',<?PHP echo $row->SL_ID; ?>,'textInput9');" value="<?php echo $row->HCB;?>">
                                          <input type="text" id="textInput9" value="<?php echo $row->HCB;?>">
                                          <br>
                                          <label for="customRange1" class="form-label">Low Current</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'LCB',<?PHP echo $row->SL_ID; ?>,'textInput10');" value="<?php echo $row->LCB;?>">
                                          <input type="text" id="textInput10" value="<?php echo $row->LCB;?>">
                                        </div>
                                        <div class="col-lg-4 mt-5">
                                          <h3 class="title-2">Set CurrentY</h3>
                                          <hr>
                                          <label for="customRange1" class="form-label">High Currrent</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'HCY',<?PHP echo $row->SL_ID; ?>,'textInput11');" value="<?php echo $row->HCY;?>">
                                          <input type="text" id="textInput11" value="<?php echo $row->HCY;?>">
                                          <br>
                                          <label for="customRange1" class="form-label">Low Current</label>
                                          <input type="range" class="form-range" id="customRange1" onchange="updateTextInput(this.value,'LCY',<?PHP echo $row->SL_ID; ?>,'textInput12');" value="<?php echo $row->LCY;?>">
                                          <input type="text" id="textInput12" value="<?php echo $row->LCY;?>">
                                        </div>

                                </div>
                                    </div>
                                </div>
                              <?php
                            }

                          ?>
                            
                            </div>

                            
                        </div>
                        <div class="row">
                          <div class="col-lg-9">
                            
                          </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="au-card au-card--no-shadow au-card--no-pad m-b-20">
                                    <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                                        <div class="bg-overlay bg-overlay--blue"></div>
                                        <h3>
                                            <i class="zmdi zmdi-account-calendar"></i>Update Location</h3>
                                        <button class="au-btn-plus">
                                            <i class="zmdi zmdi-map"></i>
                                        </button>
                                    </div>
                                    <div class="au-task js-list-load">
                                        
                                        <form action="adminup.php?id=<?php echo $_GET['SL_ID']; ?>&&Phase=<?php echo $_GET['Phase']?>" method="post" class="form-horizontal">
                                          <div class="au-task-list js-scrollbar3">
                                            <div class="au-task__item au-task__item--danger">
                                                <div class="au-task__item-inner">
                                                    <h5 class="task">
                                                        <a href="#">Location</a>
                                                    </h5>
                                                    <select class="class=au-input au-input--full" name="selectarea">
                                                      <option style="overflow-x: scroll;" value="<?php echo $row->Area ?>"><?php echo $row->Area ?></option>
                                                        <?php

                                                            require_once("EntityArea.php");
                                                            require_once("ModelArea.php");
                                                            require_once("connection.php");
                                                            global $dbc;
                                                            $area = new EntityArea();
                                                            $areaModel = new ModelArea($dbc);

                                                            $areaArrayList = $areaModel -> GetAllArea();
                                                            foreach($areaArrayList as $row1)
                                                            {
                                                        ?>
                                                        <option style="overflow-x: scroll;" value="<?php echo $row1->area_name ?>"><?php echo $row1->area_name ?></option>
                                                        
                                                    <?php }?>
                                                </div>
                                            </div>
                                            
                                            <div class="au-task__item au-task__item--warning">
                                                <div class="au-task__item-inner">
                                                    
                                                    <input type="text" class="au-input au-input--full" name="longitude" value="<?PHP echo $row->LONGITUDE ?>">
                                                </div>
                                            </div>
                                            <div class="au-task__item au-task__item--primary">
                                                <div class="au-task__item-inner">
                                                    
                                                    <input type="text" class="au-input au-input--full" name="latitude" value="<?PHP echo $row->LATITUDE ?>">
                                                </div>
                                            </div>
                                            <div class="au-task__footer">
                                                <button class="btn btn-primary" name="addarea">Update Location</button>
                                            </div>
                                        </div>
                                        </form>
                                        <hr>
                                            <div class="row">
                                                <div class="col-2"></div>
                                                  <div class="col-8">
                                                      <label for="switch" class="form-label">
                                                        <h3 class="title-2">Phone Number</h3>
                                                      </label>
                                                      <form action="updatephone.php" method="post">
                                                          <input type="number" class="au-input" value="<?php echo $row->PHONE; ?>" name="PHONE" placeholder="PhoneNumber">
                                                          <input type="text" class="au-input" value="<?php echo $_GET['SL_ID'] ?>" name="SL_ID" style="display:none;">
                                                          <button type="submit" class="btn btn-success btn-lg" name="updatephone">Update</button>  
                                                      </form>
                                                      
                                                  </div>
                                                <div class="col-2"></div>
                                            </div>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="col-lg-6">
                                <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
                                    <div class="au-card-title" style="background-image:url('images/bg-title-02.jpg');">
                                        <div class="bg-overlay bg-overlay--blue"></div>
                                        <h3>
                                            <i class="zmdi zmdi-comment-text"></i>View Map</h3>
                                        <button class="au-btn-plus">
                                            <i class="fas fa-map"></i>
                                        </button>
                                    </div>
                                    <div class="au-inbox-wrap js-inbox-wrap">
                                        <div class="au-message js-list-load">
                                            
                                    
                                      <script async
                                      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAa45i2L_EdEFQd9xKtmqwG6Pc6lfvsDKg&callback=initMap">
                                      </script>
                                      <script>
                                          // The following example creates five accessible and
                                      // focusable markers.
                                      function initMap() {
                                        const map = new google.maps.Map(document.getElementById("map"), {
                                          zoom: 20,
                                          center: { lat: <?php echo $row->LATITUDE ?>,lng: <?php echo $row->LONGITUDE ?> },
                                        });
                                        const image ="http://ironmanpro.in/images/icon/icons4.png";
                                        const image1 ="http://ironmanpro.in/images/icon/red.png";
                                        
                                        // Set LatLng and title text for the markers. The first marker (Boynton Pass)
                                        // receives the initial focus when tab is pressed. Use arrow keys to
                                        // move between markers; press tab again to cycle through the map controls.
                                        const tourStops = [
                                        <?php
                                                if ($rows->Device_Status==0)
                                                $d_status="OFF";
                                                else $d_status="ON";
                                                
                                                if ($rows->Internetconnected==0)
                                                $i_status="NO";
                                                else $i_status="YES";
                                            if ($_GET['Phase']==3) {
                                                 echo"[{fault: ".$row->FAULT."},{ lat: ".$row->LATITUDE.", lng:".$row->LONGITUDE."}, '"."Device Id :".$row->SL_ID."</br>Device Status :".$d_status."</br>Internet Connected :".$i_status."</br>Volts :".$row->VOLTR."</br> Current :".$row->CURRENTR."</br>Power :".$row->POWERR."</br>Power Factor :".$row->PFR."</br>Energy :".$row->ENERGY."</br>Frequency :".$row->FREQUENCY."'],";
                                            }
                                            else{
                                                 echo"[{fault: ".$row->FAULT."},{ lat: ".$row->LATITUDE.", lng:".$row->LONGITUDE."}, '"."Device Id :".$row->SL_ID."</br>Device Status :".$d_status."</br>Internet Connected :".$i_status."</br>Volts :".$row->VOLT."</br> Current :".$row->CURRENT."</br>Power :".$row->POWER."</br>Power Factor :".$row->PF."</br>Energy :".$row->ENERGY."</br>Frequency :".$row->FREQUENCY."'],";
                                            }
                                         
                                      

                                        ?>
                                        ];
                                        const infoWindow = new google.maps.InfoWindow();
                                        // Create an info window to share between markers.
                                       // const infoWindow = new google.maps.InfoWindow();

                                        // Create the markers.
                                        tourStops.forEach(([fault,position, title], i) => {
                                          const marker = new google.maps.Marker({
                                            position,
                                            map,
                                            icon:fault.fault==0?image:image1,
                                            title: `${title}`,
                                            //label: `${i + 1}`,
                                            optimized: false,
                                          });

                                          //infowindow content
                                          
                                          // Add a click listener for each marker, and set up the info window.
                                          marker.addListener("click", () => {
                                            infoWindow.close();
                                            infoWindow.setContent(marker.getTitle());
                                            infoWindow.open({anchor: marker,
                                            map,
                                            shouldFocus: false,});
                                          });
                                        });
                                      }
                                      </script>
                                    <div id="map" style="width: 100%; height: 550px;"></div>
                                            </div>
                                            
                                        </div>
                                        
                                            </div>
                                          
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php footer(); ?>
                    </div>
                </div>
            </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  

  <!-- Control Sidebar -->
      <!-- Control sidebar content goes here -->
  
  <!-- /.control-sidebar -->

</div>
<!-- ./wrapper -->

   <?php scriptTags() ?>
   <script type="text/javascript">
    function getValue(val) {
        console.log(val);
       var isChecked = document.getElementById(val).checked;
        
       
       if (val=="SMODE") {
        if(isChecked){
         document.getElementById("MMODE").disabled=false;
         console.log("Input is checked");
         $.ajax({
          type:"POST",
          url:"update-data.php",
          data:{KeyS:'SMODE',value:1,Target:<?PHP echo $_GET['SL_ID'] ?>},
         success:function(data){
            alert(data);
          }
         });
         } else {
          document.getElementById("MMODE").disabled=true;
          document.getElementById("MMODE").checked=false;
           console.log("Input is not  checked");
           $.ajax({
            type:"POST",
            url:"update-data.php",
            data:{KeyS:'SMODE',value:0,Target:<?PHP echo $_GET['SL_ID'] ?>},
            success:function(data){
              //alert(data);
            }
           });
          $.ajax({
            type:"POST",
            url:"update-data.php",
            data:{KeyS:'MMODE',value:0,Target:<?PHP echo $_GET['SL_ID'] ?>},
            success:function(data){
              //alert(data);
            }
          });
         }
         
        } 
        // else{
        //   var m=document.getElementById('SOMDE').checked;
        //   var s=document.getElementById('MOMDE').checked;
        //   if (m) {
        //                 window.alert("m");
        //     document.getElementById('MMODE').disabled=false;
        //     if (s) {
        //       alert("hejiu");
        //         $.ajax({
        //           type:"POST",
        //           url:"update-data.php",
        //           data:{KeyS:'MMODE',value:1,Target:<?PHP echo $_GET['SL_ID'] ?>},
        //           success:function(data){
        //             alert(data);
        //           }
        //          })
        //       }
        //       else{
        //         $.ajax({
        //           type:"POST",
        //           url:"update-data.php",
        //           data:{KeyS:'MMODE',value:0,Target:<?PHP echo $_GET['SL_ID'] ?>},
        //           success:function(data){
        //             alert(data);
        //           }
        //         })
        //       }
        //     }
        // }
        // elseif(val=="MMODE"){
        //   if (document.getElementById('SMODE').checked==true) {
        //     document.getElementById('MMODE').disabled=false;
        //     if (isChecked) {
        //       $.ajax({
        //         type:"POST",
        //         url:"update-data.php",
        //         data:{KeyS:'MMODE',value:1,Target:<?PHP echo $_GET['SL_ID'] ?>},
        //         success:function(data){
        //           //alert(data);
        //         }
        //        })
        //     }
        //     else{
        //       $.ajax({
        //         type:"POST",
        //         url:"update-data.php",
        //         data:{KeyS:'MMODE',value:0,Target:<?PHP echo $_GET['SL_ID'] ?>},
        //         success:function(data){
        //           //alert(data);
        //         }
        //       })
        //     }
        //     }
          
        // }
    }
    function getmValue(val) {
       var isChecked = document.getElementById(val).checked;
        
       
       if (val=="MMODE") {
        if(isChecked){
         console.log("Input is checked");
         $.ajax({
          type:"POST",
          url:"update-data.php",
          data:{KeyS:'MMODE',value:1,Target:<?PHP echo $_GET['SL_ID'] ?>},
          success:function(data){
            //alert(data);
            let id=document.getElementById("d_status");
            id.src="http://ironmanpro.in/images/icon/pon.png";
          }
         })
         } else {
           console.log("Input is not  checked");
           $.ajax({
            type:"POST",
            url:"update-data.php",
            data:{KeyS:'MMODE',value:0,Target:<?PHP echo $_GET['SL_ID'] ?>},
            success:function(data){
                let id=document.getElementById("d_status");
            id.src="http://ironmanpro.in/images/icon/poff.png";
            }
           })
         }
         
        } 
    }
    function getpValue(val) {
       var isChecked = document.getElementById(val).checked;
        
       
       if (val=="Phasestatus") {
        if(isChecked){
         console.log("Input is checked");
         $.ajax({
          type:"POST",
          url:"update-data.php",
          data:{KeyS:'PHASE',value:3,Target:<?PHP echo $_GET['SL_ID'] ?>},
          success:function(data){
            window.location="viewstreetlightdetail.php?SL_ID=<?PHP echo $_GET['SL_ID'] ?>&&Phase=3";
          }
         })
         } else {
           console.log("Input is not  checked");
           $.ajax({
            type:"POST",
            url:"update-data.php",
            data:{KeyS:'PHASE',value:1,Target:<?PHP echo $_GET['SL_ID'] ?>},
            success:function(data){
              window.location="viewstreetlightdetail.php?SL_ID=<?PHP echo $_GET['SL_ID'] ?>&&Phase=1";
            }
           })
         }
         
        } 
    }
     function updateTextInput(val,key,target,oputid) {
         // document.getElementById(oputid).value=val; 
          $.ajax({
            type:"POST",
            url:"update-data.php",
            data:{value:val,KeyS:key,Target:target},
            success:function(data){
              //alert(data);
              document.getElementById(oputid).value=val; 
            }
          })
        }

    
   
   </script>
</body>
</html>
