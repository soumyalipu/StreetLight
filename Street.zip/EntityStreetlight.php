<?php
class EntityStreetlight
{
	public $ID;
	public $SL_ID;
	public $PHASE;
	public $R_WATT;
	public $Area;
	public $LONGITUDE;
	public $LATITUDE;
}
?>