
<?php
class EntitySl_status
{
	public $ID;
	public $SL_ID;
	public $SL_PASS;
	public $POWER;
	public $CURRENT;
	public $VOLT;
	public $LOW_VOLT;
	public $HIGH_VOLT;
	public $D1;
	public $D2;
	public $D3;
	public $D4;
	public $ADC1;
	public $ADC2;
	public $ADC3;
	public $ADC4;
	public $LONGITUDE;
	public $LATITUDE;
	public $DATE;
	public $TIME;
	public $Internetconnected;
	public $Area;
	public $Device_Status;
	public $VOLTR;
	public $VOLTB;
	public $VOLTY;
	public $HVR;
	public $HVB;
	public $HBY;
	public $LVR;
	public $LVB;
	public $LVY;
	public $CY;
	public $CR;
	public $CB;
	public $PHASE;
	public $SMODE;
	public $MMODE;
	public $FAULT;
	public $BRIGHTNESS;
	public $ENERGY;
	public $HCY;
	public $LCY;
	public $HCB;
	public $LCB;
	public $HCR;
	public $LCR;
	public $WATT;
}
?>