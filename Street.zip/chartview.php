<?php
ob_start();
    include("connection.php");
  include("function.php");
  if(!isset($_SESSION['user']))
{
    header("Location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php headContent("FILENAME");?>
</head>
<body class="animsition">
<div class="page-wrapper">

  <!-- Navbar -->
  
  <!-- /.navbar -->

  <!-- Start: Main Sidebar Container -->
  <?php $utype=$_SESSION['usertype']; mobile($utype);sideBar($utype); ?>
  <!-- End: Main Sidebar Container -->

  <!-- Content Wrapper. Contains page content -->
  <div class="page-container">
  <?php headerdesktop(); ?>

    <!-- Main content -->
    <div class="main-content">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="au-card m-b-30">
                                    <div class="au-card-inner">
                                        <form action="" method="GET">
                                            <select name="optionname">
                                                <?php 
                                                    if($_GET['Phase']==1){
                                                    ?>
                                                    	<option value="VOLT">VOLT</option>
	                                                <option value="CURRENT">CURRENT</option>
	                                                <option value="POWER">POWER</option>
	                                                <option value="WATT">ENERGY</option>
                                                    <?php
                                                        
                                                    }
                                                    elseif($_GET['Phase']==3){
                                            	   ?>
                                            		<option value="VOLTR">VOLTR</option>
	                                                <option value="VOLTB">VOLTB</option>
	                                                <option value="VOLTY">VOLTY</option>
	                                                <option value="CY">CURRENTY</option>
	                                                <option value="CR">CURRENTR</option>
	                                                <option value="CB">CURRENTB</option>
	                                                <option value="POWERR">POWERR</option>
	                                                <option value="POWERY">POWERY</option>
	                                                <option value="POWERB">POWERB</option>
	                                                <option value="WATT">ENERGY</option>
                                            	
                                            	   <?php
                                                    }
                                                    
                                                ?>
                                                
                                                
                                            </select>
                                            <br>
                                            F Date: <input type="date" name="fdate" required>
                                           &ensp;&ensp;&ensp;
                                            T Date: <input type="date" name="tdate" required>
                                            <br>
                                            <input type="text" name="Sl_id" value="<?php echo $_GET['Sl_id']?>" style="display: none;">
                                            <input type="text" name="Phase" value="<?php echo $_GET['Phase']?>" style="display: none;">
                                            <input type="submit" name="view" value="view">
                                        </form>
                                        <div id="curve_chart"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="col-lg-6">
                                <div class="au-card m-b-30">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Yearly Sales</h3>
                                        <canvas id="sales-chart"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="au-card m-b-30">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Team Commits</h3>
                                        <canvas id="team-chart"></canvas>
                                    </div>
                                </div>
                            </div> -->
                            
                        </div>
                        <?php echo footer(); ?>
                    </div>
                </div>
            </div>
        </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  

  <!-- Control Sidebar -->
      <!-- Control sidebar content goes here -->
  
  <!-- /.control-sidebar -->

</div>
<!-- ./wrapper -->
    
   <?php scriptTags() ?>
   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
   <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
            ['Year', 'Data'],
            <?php
                if (isset($_GET['view'])) {
                    require_once("EntitySinglephase_status.php");
                    require_once("ModelSinglephase_status.php");
                    require_once("EntityMultiphase_status.php");
                    require_once("ModelMultiphase_status.php");
                    require_once("connection.php");
                    global $dbc;
                    $singlephase_status = new EntitySinglephase_status();
                    $singlephase_statusModel = new ModelSinglephase_status($dbc);
                    $multiphase_status = new EntityMultiphase_status();
                    $multiphase_statusModel = new ModelMultiphase_status($dbc);
                    $vtype=$_GET['optionname'];
                    $fdate=$_GET['fdate'];
                    $tdate=$_GET['tdate'];
                    if ($_GET['Phase']==1) {
                        $sl_statusArrayList = $singlephase_statusModel -> filtervolt($fdate,$tdate,$_GET['Sl_id']);
                    }
                    elseif ($_GET['Phase']==3) {
                        $sl_statusArrayList = $multiphase_statusModel -> filtervolt($fdate,$tdate,$_GET['Sl_id']);
                    }
                    
                    foreach($sl_statusArrayList as $row){
                        
                    if ($_GET['optionname']=="VOLT") {
                        ?>

                        ['<?php echo $row->DATE ?>',  <?php echo $row->VOLT ?>],
                        <?php }
                    
                    elseif ($_GET['optionname']=="CURRENT") {
                        ?>
                        ['<?php echo $row->DATE ?>',  <?php echo $row->CURRENT ?>],
                        <?php }
                    
                    elseif ($_GET['optionname']=="POWER") {
                        ?>
                        ['<?php echo $row->DATE ?>',  <?php echo $row->POWER ?>],
                        <?php }
                    elseif ($_GET['optionname']=="VOLTR") {
                        ?>
                        ['<?php echo $row->DATE ?>',  <?php echo $row->VOLTR ?>],
                        <?php }
                    
                    elseif ($_GET['optionname']=="VOLTB") {
                        ?>
                        ['<?php echo $row->DATE ?>',  <?php echo $row->VOLTB ?>],
                        <?php }
                    elseif ($_GET['optionname']=="VOLTY") {
                        ?>
                        ['<?php echo $row->DATE ?>',  <?php echo $row->VOLTY ?>],
                        <?php }
                    elseif ($_GET['optionname']=="CY") {
                        ?>
                        ['<?php echo $row->DATE ?>',  <?php echo $row->CURRENTY ?>],
                        <?php }
                    elseif ($_GET['optionname']=="CR") {
                        ?>
                        ['<?php echo $row->DATE ?>',  <?php echo $row->CURRENTR ?>],
                        <?php }
                    elseif ($_GET['optionname']=="CB") {
                        ?>
                        ['<?php echo $row->DATE ?>',  <?php echo $row->CURRENTB ?>],
                        <?php }
                    elseif ($_GET['optionname']=="WATT") {
                        ?>
                        ['<?php echo $row->DATE ?>',  <?php echo $row->WATT ?>],
                        <?php }}
                }
                else{
                    if ($_GET['Phase']==1) {
                        require_once("EntitySinglephase_status.php");
                        require_once("ModelSinglephase_status.php");
                        require_once("connection.php");
                        global $dbc;
                        $singlephase_status = new EntitySinglephase_status();
                        $singlephase_statusModel = new ModelSinglephase_status($dbc);
                        $sl_statusArrayList = $singlephase_statusModel -> GetSinglephase_statusBySl_id($_GET['Sl_id'])[0];
                        $V=$sl_statusArrayList->VOLT;
                    }
                    elseif ($_GET['Phase']==3) {
                        require_once("EntityMultiphase_status.php");
                        require_once("ModelMultiphase_status.php");
                        require_once("connection.php");
                        global $dbc;
                        $multiphase_status = new EntityMultiphase_status();
                        $multiphase_statusModel = new ModelMultiphase_status($dbc);
                        $sl_statusArrayList = $multiphase_statusModel -> GetMultiphase_statusBySl_id($_GET['Sl_id'])[0];
                        $V=$sl_statusArrayList->VOLTR;
                    }
                    foreach($sl_statusArrayList as $row){
                
                    ?>
                    ['<?php echo $row->DATE ?>',  <?php echo $V; ?>],
                            <?php }}?>
                
        ]);

        var options = {
          title: 'AC Power Analysis',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
</body>
</html>
