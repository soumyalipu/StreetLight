
<?php
class EntitySuperadmin
{
	public $ID;
	public $SADMINUID;
	public $SADMINPASSWORD;
}
?>