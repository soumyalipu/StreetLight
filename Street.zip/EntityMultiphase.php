
<?php
class EntityMultiphase
{
	public $ID;
	public $SL_ID;
	public $POWERR;
	public $POWERY;
	public $POWERB;
	public $CURRENTR;
	public $CURRENTY;
	public $CURRENTB;
	public $VOLTR;
	public $VOLTY;
	public $VOLTB;
	public $LOW_VOLTR;
	public $LOW_VOLTY;
	public $LOW_VOLTB;
	public $HIGH_VOLTR;
	public $HIGH_VOLTY;
	public $HIGH_VOLTB;
	public $PFR;
	public $PFY;
	public $PFB;
	public $HCR;
	public $HCY;
	public $HCB;
	public $LCR;
	public $LCY;
	public $LCB;
	public $A_M_TIME;
	public $A_E_TIME;
	public $LONGITUDE;
	public $LATITUDE;
	public $DATE;
	public $TIME;
	public $Internetconnected;
	public $Area;
	public $Device_Status;
	public $FREQUENCY;
	public $SMODE;
	public $MMODE;
	public $FAULT;
	public $R_WATT;
	public $ENERGY;
	public $PHONE;
}
?>