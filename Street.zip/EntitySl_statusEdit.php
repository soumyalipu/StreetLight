<?php
    include("connection.php");
	include("function.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php headContent("EntitySl_statusEdit");?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
	<?php navBar(); ?>
  <!-- /.navbar -->

  <!-- Start: Main Sidebar Container -->
	<?php sideBar(); ?>
  <!-- End: Main Sidebar Container -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
	  
	   
<!-- Start: Retrive Data -->
<?php

	require_once("EntitySl_status.php");
	require_once("ModelSl_status.php");
	require_once("connection.php");
	global $dbc;
	$sl_status = new EntitySl_status();
	$sl_statusModel = new ModelSl_status($dbc);

	$sl_status = $sl_statusModel -> GetSl_statusById($_GET["ID"])[0];
?>
<!-- End: Retrive Data-->

<!-- Start: Edit Form HTML-->
<div class="container">
	<h3 class="w3-padding w3-card-2 w3-blue">Edit Sl_status</h3>
	<div class="w3-card-2 w3-padding " style="margin-top:-12px;overflow-x:scroll" >
		<form method="POST" enctype="multipart/form-data" >

			<!-- Start: Input Field For ID-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Id</label>
				<input type="number" placeholder="Please enter ID ..." class="w3-input form-control" name="ID" id="ID"  value="<?php echo $sl_status->ID; ?>" />
			</div>
			<!-- End: Input Field For ID-->


			<!-- Start: Input Field For SL_ID-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Sl_id</label>
				<input type="number" placeholder="Please enter SL_ID ..." class="w3-input form-control" name="SL_ID" id="SL_ID"  value="<?php echo $sl_status->SL_ID; ?>" />
			</div>
			<!-- End: Input Field For SL_ID-->


			<!-- Start: Input Field For SL_PASS-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Sl_pass</label>
				<input type="text" placeholder="Please enter SL_PASS ..." class="w3-input form-control" name="SL_PASS" id="SL_PASS"  value="<?php echo $sl_status->SL_PASS; ?>" />
			</div>
			<!-- End: Input Field For SL_PASS-->


			<!-- Start: Input Field For POWER-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Power</label>
				<input type="text" placeholder="Please enter POWER ..." class="w3-input form-control" name="POWER" id="POWER"  value="<?php echo $sl_status->POWER; ?>" />
			</div>
			<!-- End: Input Field For POWER-->


			<!-- Start: Input Field For CURRENT-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Current</label>
				<input type="text" placeholder="Please enter CURRENT ..." class="w3-input form-control" name="CURRENT" id="CURRENT"  value="<?php echo $sl_status->CURRENT; ?>" />
			</div>
			<!-- End: Input Field For CURRENT-->


			<!-- Start: Input Field For VOLT-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Volt</label>
				<input type="text" placeholder="Please enter VOLT ..." class="w3-input form-control" name="VOLT" id="VOLT"  value="<?php echo $sl_status->VOLT; ?>" />
			</div>
			<!-- End: Input Field For VOLT-->


			<!-- Start: Input Field For LOW_VOLT-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Low_volt</label>
				<input type="text" placeholder="Please enter LOW_VOLT ..." class="w3-input form-control" name="LOW_VOLT" id="LOW_VOLT"  value="<?php echo $sl_status->LOW_VOLT; ?>" />
			</div>
			<!-- End: Input Field For LOW_VOLT-->


			<!-- Start: Input Field For HIGH_VOLT-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> High_volt</label>
				<input type="text" placeholder="Please enter HIGH_VOLT ..." class="w3-input form-control" name="HIGH_VOLT" id="HIGH_VOLT"  value="<?php echo $sl_status->HIGH_VOLT; ?>" />
			</div>
			<!-- End: Input Field For HIGH_VOLT-->


			<!-- Start: Input Field For D1-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> D1</label>
				<input type="number" placeholder="Please enter D1 ..." class="w3-input form-control" name="D1" id="D1"  value="<?php echo $sl_status->D1; ?>" />
			</div>
			<!-- End: Input Field For D1-->


			<!-- Start: Input Field For D2-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> D2</label>
				<input type="number" placeholder="Please enter D2 ..." class="w3-input form-control" name="D2" id="D2"  value="<?php echo $sl_status->D2; ?>" />
			</div>
			<!-- End: Input Field For D2-->


			<!-- Start: Input Field For D3-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> D3</label>
				<input type="number" placeholder="Please enter D3 ..." class="w3-input form-control" name="D3" id="D3"  value="<?php echo $sl_status->D3; ?>" />
			</div>
			<!-- End: Input Field For D3-->


			<!-- Start: Input Field For D4-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> D4</label>
				<input type="number" placeholder="Please enter D4 ..." class="w3-input form-control" name="D4" id="D4"  value="<?php echo $sl_status->D4; ?>" />
			</div>
			<!-- End: Input Field For D4-->


			<!-- Start: Input Field For ADC1-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Adc1</label>
				<input type="number" placeholder="Please enter ADC1 ..." class="w3-input form-control" name="ADC1" id="ADC1"  value="<?php echo $sl_status->ADC1; ?>" />
			</div>
			<!-- End: Input Field For ADC1-->


			<!-- Start: Input Field For ADC2-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Adc2</label>
				<input type="number" placeholder="Please enter ADC2 ..." class="w3-input form-control" name="ADC2" id="ADC2"  value="<?php echo $sl_status->ADC2; ?>" />
			</div>
			<!-- End: Input Field For ADC2-->


			<!-- Start: Input Field For ADC3-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Adc3</label>
				<input type="number" placeholder="Please enter ADC3 ..." class="w3-input form-control" name="ADC3" id="ADC3"  value="<?php echo $sl_status->ADC3; ?>" />
			</div>
			<!-- End: Input Field For ADC3-->


			<!-- Start: Input Field For ADC4-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Adc4</label>
				<input type="number" placeholder="Please enter ADC4 ..." class="w3-input form-control" name="ADC4" id="ADC4"  value="<?php echo $sl_status->ADC4; ?>" />
			</div>
			<!-- End: Input Field For ADC4-->


			<!-- Start: Input Field For LONGITUDE-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Longitude</label>
				<input type="text" placeholder="Please enter LONGITUDE ..." class="w3-input form-control" name="LONGITUDE" id="LONGITUDE"  value="<?php echo $sl_status->LONGITUDE; ?>" />
			</div>
			<!-- End: Input Field For LONGITUDE-->


			<!-- Start: Input Field For LATITUDE-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Latitude</label>
				<input type="text" placeholder="Please enter LATITUDE ..." class="w3-input form-control" name="LATITUDE" id="LATITUDE"  value="<?php echo $sl_status->LATITUDE; ?>" />
			</div>
			<!-- End: Input Field For LATITUDE-->


			<!-- Start: Input Field For DATE-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Date</label>
				<input type="text" placeholder="Please enter DATE ..." class="w3-input form-control" name="DATE" id="DATE"  value="<?php echo $sl_status->DATE; ?>" />
			</div>
			<!-- End: Input Field For DATE-->


			<!-- Start: Input Field For TIME-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Time</label>
				<input type="text" placeholder="Please enter TIME ..." class="w3-input form-control" name="TIME" id="TIME"  value="<?php echo $sl_status->TIME; ?>" />
			</div>
			<!-- End: Input Field For TIME-->


			<!-- Start: Input Field For Internetconnected-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Internetconnected</label>
				<input type="number" placeholder="Please enter Internetconnected ..." class="w3-input form-control" name="Internetconnected" id="Internetconnected"  value="<?php echo $sl_status->Internetconnected; ?>" />
			</div>
			<!-- End: Input Field For Internetconnected-->


			<!-- Start: Input Field For Area-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Area</label>
				<input type="text" placeholder="Please enter Area ..." class="w3-input form-control" name="Area" id="Area"  value="<?php echo $sl_status->Area; ?>" />
			</div>
			<!-- End: Input Field For Area-->


			<!-- Start: Input Field For Device_Status-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Device_status</label>
				<input type="number" placeholder="Please enter Device_Status ..." class="w3-input form-control" name="Device_Status" id="Device_Status"  value="<?php echo $sl_status->Device_Status; ?>" />
			</div>
			<!-- End: Input Field For Device_Status-->


			<!-- Start: Input Field For VOLTR-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Voltr</label>
				<input type="text" placeholder="Please enter VOLTR ..." class="w3-input form-control" name="VOLTR" id="VOLTR"  value="<?php echo $sl_status->VOLTR; ?>" />
			</div>
			<!-- End: Input Field For VOLTR-->


			<!-- Start: Input Field For VOLTB-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Voltb</label>
				<input type="text" placeholder="Please enter VOLTB ..." class="w3-input form-control" name="VOLTB" id="VOLTB"  value="<?php echo $sl_status->VOLTB; ?>" />
			</div>
			<!-- End: Input Field For VOLTB-->


			<!-- Start: Input Field For VOLTY-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Volty</label>
				<input type="text" placeholder="Please enter VOLTY ..." class="w3-input form-control" name="VOLTY" id="VOLTY"  value="<?php echo $sl_status->VOLTY; ?>" />
			</div>
			<!-- End: Input Field For VOLTY-->


			<!-- Start: Input Field For HVR-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Hvr</label>
				<input type="text" placeholder="Please enter HVR ..." class="w3-input form-control" name="HVR" id="HVR"  value="<?php echo $sl_status->HVR; ?>" />
			</div>
			<!-- End: Input Field For HVR-->


			<!-- Start: Input Field For HVB-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Hvb</label>
				<input type="text" placeholder="Please enter HVB ..." class="w3-input form-control" name="HVB" id="HVB"  value="<?php echo $sl_status->HVB; ?>" />
			</div>
			<!-- End: Input Field For HVB-->


			<!-- Start: Input Field For HBY-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Hby</label>
				<input type="text" placeholder="Please enter HBY ..." class="w3-input form-control" name="HBY" id="HBY"  value="<?php echo $sl_status->HBY; ?>" />
			</div>
			<!-- End: Input Field For HBY-->


			<!-- Start: Input Field For LVR-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Lvr</label>
				<input type="text" placeholder="Please enter LVR ..." class="w3-input form-control" name="LVR" id="LVR"  value="<?php echo $sl_status->LVR; ?>" />
			</div>
			<!-- End: Input Field For LVR-->


			<!-- Start: Input Field For LVB-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Lvb</label>
				<input type="text" placeholder="Please enter LVB ..." class="w3-input form-control" name="LVB" id="LVB"  value="<?php echo $sl_status->LVB; ?>" />
			</div>
			<!-- End: Input Field For LVB-->


			<!-- Start: Input Field For LVY-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Lvy</label>
				<input type="text" placeholder="Please enter LVY ..." class="w3-input form-control" name="LVY" id="LVY"  value="<?php echo $sl_status->LVY; ?>" />
			</div>
			<!-- End: Input Field For LVY-->


			<!-- Start: Input Field For CY-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Cy</label>
				<input type="text" placeholder="Please enter CY ..." class="w3-input form-control" name="CY" id="CY"  value="<?php echo $sl_status->CY; ?>" />
			</div>
			<!-- End: Input Field For CY-->


			<!-- Start: Input Field For CR-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Cr</label>
				<input type="text" placeholder="Please enter CR ..." class="w3-input form-control" name="CR" id="CR"  value="<?php echo $sl_status->CR; ?>" />
			</div>
			<!-- End: Input Field For CR-->


			<!-- Start: Input Field For CB-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Cb</label>
				<input type="text" placeholder="Please enter CB ..." class="w3-input form-control" name="CB" id="CB"  value="<?php echo $sl_status->CB; ?>" />
			</div>
			<!-- End: Input Field For CB-->


			<!-- Start: Input Field For PHASE-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Phase</label>
				<input type="number" placeholder="Please enter PHASE ..." class="w3-input form-control" name="PHASE" id="PHASE"  value="<?php echo $sl_status->PHASE; ?>" />
			</div>
			<!-- End: Input Field For PHASE-->


			<!-- Start: Input Field For SMODE-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Smode</label>
				<input type="number" placeholder="Please enter SMODE ..." class="w3-input form-control" name="SMODE" id="SMODE"  value="<?php echo $sl_status->SMODE; ?>" />
			</div>
			<!-- End: Input Field For SMODE-->


			<!-- Start: Input Field For MMODE-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Mmode</label>
				<input type="number" placeholder="Please enter MMODE ..." class="w3-input form-control" name="MMODE" id="MMODE"  value="<?php echo $sl_status->MMODE; ?>" />
			</div>
			<!-- End: Input Field For MMODE-->


			<!-- Start: Input Field For FAULT-->
			<div class="form-group col-md-12">
				<label><i class="null"></i> Fault</label>
				<input type="number" placeholder="Please enter FAULT ..." class="w3-input form-control" name="FAULT" id="FAULT"  value="<?php echo $sl_status->FAULT; ?>" />
			</div>
			<!-- End: Input Field For FAULT-->


			<!-- Start: Submit Button-->
			<div class="col-md-12">
				<div class="form-group">
					<button class="w3-btn w3-small w3-round w3-blue" name="submitForm" >Submit</button>
					<a href="EntitySl_statusList.php" class="w3-btn w3-small w3-round w3-red" >Back</a>
				</div>
			</div>
			<!-- End: Submit Button-->

		</form>
	</div>
</div>
<!-- End: Edit Form HTML-->

<!-- Start: Edit Form PHP-->
<?php
	if(isset($_POST["submitForm"]))
	{

		$sl_status->ID = $_POST["ID"];
		$sl_status->SL_ID = $_POST["SL_ID"];
		$sl_status->SL_PASS = $_POST["SL_PASS"];
		$sl_status->POWER = $_POST["POWER"];
		$sl_status->CURRENT = $_POST["CURRENT"];
		$sl_status->VOLT = $_POST["VOLT"];
		$sl_status->LOW_VOLT = $_POST["LOW_VOLT"];
		$sl_status->HIGH_VOLT = $_POST["HIGH_VOLT"];
		$sl_status->D1 = $_POST["D1"];
		$sl_status->D2 = $_POST["D2"];
		$sl_status->D3 = $_POST["D3"];
		$sl_status->D4 = $_POST["D4"];
		$sl_status->ADC1 = $_POST["ADC1"];
		$sl_status->ADC2 = $_POST["ADC2"];
		$sl_status->ADC3 = $_POST["ADC3"];
		$sl_status->ADC4 = $_POST["ADC4"];
		$sl_status->LONGITUDE = $_POST["LONGITUDE"];
		$sl_status->LATITUDE = $_POST["LATITUDE"];
		$sl_status->DATE = $_POST["DATE"];
		$sl_status->TIME = $_POST["TIME"];
		$sl_status->Internetconnected = $_POST["Internetconnected"];
		$sl_status->Area = $_POST["Area"];
		$sl_status->Device_Status = $_POST["Device_Status"];
		$sl_status->VOLTR = $_POST["VOLTR"];
		$sl_status->VOLTB = $_POST["VOLTB"];
		$sl_status->VOLTY = $_POST["VOLTY"];
		$sl_status->HVR = $_POST["HVR"];
		$sl_status->HVB = $_POST["HVB"];
		$sl_status->HBY = $_POST["HBY"];
		$sl_status->LVR = $_POST["LVR"];
		$sl_status->LVB = $_POST["LVB"];
		$sl_status->LVY = $_POST["LVY"];
		$sl_status->CY = $_POST["CY"];
		$sl_status->CR = $_POST["CR"];
		$sl_status->CB = $_POST["CB"];
		$sl_status->PHASE = $_POST["PHASE"];
		$sl_status->SMODE = $_POST["SMODE"];
		$sl_status->MMODE = $_POST["MMODE"];
		$sl_status->FAULT = $_POST["FAULT"];

		if($sl_statusModel -> UpdateSl_status($sl_status))
		{
			 echo '<script>alert("Sl_status updated successfully...");window.location=window.location.href;</script>';
		}
		else
		{
			 echo '<script>alert("Unable to updated Sl_status ...");window.location=window.location.href;</script>';
		}
	}
?>
<!-- End: Edit Form PHP-->

	   
	  </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  <footer class="main-footer">
    <strong>Copyright &copy; 2021 SSSTech</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.1.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

</div>
<!-- ./wrapper -->

   <?php scriptTags() ?>
</body>
</html>
