
<?php
class EntitySinglephase
{
	public $ID;
	public $SL_ID;
	public $POWER;
	public $CURRENT;
	public $VOLT;
	public $LOW_VOLT;
	public $HIGH_VOLT;
	public $PF;
	public $HC;
	public $LC;
	public $A_M_TIME;
	public $A_E_TIME;
	public $LONGITUDE;
	public $LATITUDE;
	public $DATE;
	public $TIME;
	public $Internetconnected;
	public $Area;
	public $Device_Status;
	public $FREQUENCY;
	public $SMODE;
	public $MMODE;
	public $FAULT;
	public $R_WATT;
	public $ENERGY;
	public $PHONE;
}
?>